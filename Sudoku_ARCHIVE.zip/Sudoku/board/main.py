# from user import Board
from board import Board
from prover import Prover
from random import randrange
#
# board = Board("testavail")
# print board.getAvailableInSpace(5, 5)
# board.prettyPrint()



board = Board("solved.txt")
board.prettyPrint()

prover = Prover(board)

cont = True
for i in range(30):
    x = randrange(9)
    y = randrange(9)
    if(cont):
        prover = Prover(board)
        if(prover.isRemoveValid(x, y)):
            board.removeElement(x, y)
            board.prettyPrint()
            print('\n')

        else:
            board.removeElement(x, y)
            board.prettyPrint()
            print('REMOVE NOT VALID: ' + str(x) + ", " +  str(y))
            print("INVALID BOARD:")
            cont = False

